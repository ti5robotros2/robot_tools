// Copyright 2023 ros2_control Development Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <vector>
#include <string>
#include <cmath>

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<rclcpp::Node>("send_walking_joint_commands");

  // 创建发布者，发布到 /joint_commands
  auto pub = node->create_publisher<sensor_msgs::msg::JointState>("/joint_commands", 10);

  // 定义关节名称列表（23个关节）
  std::vector<std::string> joint_names = {
    "r_arm_joint1", "r_arm_joint2", "R_SHOULDER_R", "R_SHOULDER_Y",
    "l_arm_joint1", "l_arm_joint2", "L_SHOULDER_R", "L_SHOULDER_Y",
    "leg_r1_joint", "leg_r2_joint", "leg_r3_joint", "leg_r4_joint",
    "leg_r5_joint", "leg_r6_joint", "leg_l1_joint", "leg_l2_joint",
    "leg_l3_joint", "leg_l4_joint", "leg_l5_joint", "leg_l6_joint",
    "WAIST_Y", "WAIST_P", "WAIST_R"
  };

  // 设置发布频率 (10 Hz)
  rclcpp::Rate rate(10);
  double time = 0.0;
  const double step_period = 1.0;  // 步态周期为1秒
  const double dt = 1.0 / 10.0;    // 时间步长（10 Hz）

  RCLCPP_INFO(node->get_logger(), "开始发布优化步态的行走命令到 /joint_commands，关节数量: %zu", joint_names.size());

  while (rclcpp::ok())
  {
    // 创建 JointState 消息
    sensor_msgs::msg::JointState joint_state_msg;
    joint_state_msg.header.stamp = node->now();
    joint_state_msg.name = joint_names;
    joint_state_msg.position.resize(joint_names.size(), 0.0);
    joint_state_msg.velocity.resize(joint_names.size(), 0.0);

    // 计算步态相位（0到1的周期）
    double phase = std::fmod(time / step_period, 1.0);  // 归一化到[0,1]

    // 为所有关节生成运动
    for (size_t i = 0; i < joint_names.size(); ++i)
    {
      // 右腿关节（优化步态）
      if (joint_names[i] == "leg_r1_joint")  // 辅助关节
      {
        joint_state_msg.position[i] = 0.1 * std::sin(2.0 * M_PI * phase);
        joint_state_msg.velocity[i] = 0.1 * 2.0 * M_PI * std::cos(2.0 * M_PI * phase);
      }
      else if (joint_names[i] == "leg_r2_joint")  // 左右摆动（髋横向）
      {
        double pos;
        if (phase < 0.6)  // 支撑期：轻微内收
          pos = -0.05;
        else  // 摆动期：轻微外展
          pos = 0.05;
        joint_state_msg.position[i] = pos;
        joint_state_msg.velocity[i] = 0.0;  // 左右摆动速度较小
      }
      else if (joint_names[i] == "leg_r3_joint" || joint_names[i] == "leg_r4_joint")  // 前后运动（髋前后，反向）
      {
        double pos;
        if (phase < 0.6)  // 支撑期：从后到前（反向）
          pos = -0.3 + 0.6 * (phase / 0.6);  // 从-0.3（后）到0.3（前）
        else  // 摆动期：从前到后（反向）
          pos = 0.3 - 0.6 * ((phase - 0.6) / 0.4);  // 从0.3回到-0.3
        joint_state_msg.position[i] = pos;
        joint_state_msg.velocity[i] = (phase < 0.6) ? 0.6 / 0.6 : -0.6 / 0.4;  // 速度反向
      }
      else if (joint_names[i] == "leg_r5_joint")  // 膝关节（屈伸）
      {
        double pos;
        if (phase < 0.4)  // 支撑期前段：伸直
          pos = 0.0;
        else if (phase < 0.6)  // 支撑期后段：微屈
          pos = 0.05;
        else  // 摆动期：更高屈曲后伸展
          pos = 0.8 * std::sin(2.0 * M_PI * (phase - 0.6) / 0.4);  // 屈曲到0.8后回到0
        joint_state_msg.position[i] = pos;
        joint_state_msg.velocity[i] = (phase < 0.4) ? 0.0
                                    : (phase < 0.6) ? 0.0
                                                    : 0.8 * 2.0 * M_PI / 0.4 * std::cos(2.0 * M_PI * (phase - 0.6) / 0.4);
      }
      else if (joint_names[i] == "leg_r6_joint")  // 辅助关节
      {
        joint_state_msg.position[i] = 0.1 * std::sin(2.0 * M_PI * phase);
        joint_state_msg.velocity[i] = 0.1 * 2.0 * M_PI * std::cos(2.0 * M_PI * phase);
      }
      // 左腿关节（优化步态，与右腿相差180°）
      else if (joint_names[i] == "leg_l1_joint")  // 辅助关节
      {
        double left_phase = std::fmod(phase + 0.5, 1.0);
        joint_state_msg.position[i] = 0.1 * std::sin(2.0 * M_PI * left_phase);
        joint_state_msg.velocity[i] = 0.1 * 2.0 * M_PI * std::cos(2.0 * M_PI * left_phase);
      }
      else if (joint_names[i] == "leg_l2_joint")  // 左右摆动（髋横向）
      {
        double left_phase = std::fmod(phase + 0.5, 1.0);
        double pos;
        if (left_phase < 0.6)  // 支撑期：轻微内收
          pos = -0.05;
        else  // 摆动期：轻微外展
          pos = 0.05;
        joint_state_msg.position[i] = pos;
        joint_state_msg.velocity[i] = 0.0;
      }
      else if (joint_names[i] == "leg_l3_joint" || joint_names[i] == "leg_l4_joint")  // 前后运动（髋前后，反向）
      {
        double left_phase = std::fmod(phase + 0.5, 1.0);
        double pos;
        if (left_phase < 0.6)  // 支撑期：从后到前（反向）
          pos = -0.3 + 0.6 * (left_phase / 0.6);
        else  // 摆动期：从前到后（反向）
          pos = 0.3 - 0.6 * ((left_phase - 0.6) / 0.4);
        joint_state_msg.position[i] = pos;
        joint_state_msg.velocity[i] = (left_phase < 0.6) ? 0.6 / 0.6 : -0.6 / 0.4;
      }
      else if (joint_names[i] == "leg_l5_joint")  // 膝关节（屈伸）
      {
        double left_phase = std::fmod(phase + 0.5, 1.0);
        double pos;
        if (left_phase < 0.4)  // 支撑期前段：伸直
          pos = 0.0;
        else if (left_phase < 0.6)  // 支撑期后段：微屈
          pos = 0.05;
        else  // 摆动期：更高屈曲后伸展
          pos = 0.8 * std::sin(2.0 * M_PI * (left_phase - 0.6) / 0.4);
        joint_state_msg.position[i] = pos;
        joint_state_msg.velocity[i] = (left_phase < 0.4) ? 0.0
                                    : (left_phase < 0.6) ? 0.0
                                                    : 0.8 * 2.0 * M_PI / 0.4 * std::cos(2.0 * M_PI * (left_phase - 0.6) / 0.4);
      }
      else if (joint_names[i] == "leg_l6_joint")  // 辅助关节
      {
        double left_phase = std::fmod(phase + 0.5, 1.0);
        joint_state_msg.position[i] = 0.1 * std::sin(2.0 * M_PI * left_phase);
        joint_state_msg.velocity[i] = 0.1 * 2.0 * M_PI * std::cos(2.0 * M_PI * left_phase);
      }
      // 右臂关节
      else if (joint_names[i] == "r_arm_joint1")
      {
        joint_state_msg.position[i] = 0.4 * std::sin(2.0 * M_PI * phase + M_PI);
        joint_state_msg.velocity[i] = 0.4 * 2.0 * M_PI * std::cos(2.0 * M_PI * phase + M_PI);
      }
      else if (joint_names[i] == "r_arm_joint2")
      {
        joint_state_msg.position[i] = 0.2 * std::sin(2.0 * M_PI * phase + M_PI + M_PI / 4);
        joint_state_msg.velocity[i] = 0.2 * 2.0 * M_PI * std::cos(2.0 * M_PI * phase + M_PI + M_PI / 4);
      }
      // 左臂关节
      else if (joint_names[i] == "l_arm_joint1")
      {
        joint_state_msg.position[i] = 0.4 * std::sin(2.0 * M_PI * phase);
        joint_state_msg.velocity[i] = 0.4 * 2.0 * M_PI * std::cos(2.0 * M_PI * phase);
      }
      else if (joint_names[i] == "l_arm_joint2")
      {
        joint_state_msg.position[i] = 0.2 * std::sin(2.0 * M_PI * phase + M_PI / 4);
        joint_state_msg.velocity[i] = 0.2 * 2.0 * M_PI * std::cos(2.0 * M_PI * phase + M_PI / 4);
      }
      // 右肩关节
      else if (joint_names[i] == "R_SHOULDER_R")
      {
        joint_state_msg.position[i] = 0.1 * std::sin(2.0 * M_PI * phase + M_PI);
        joint_state_msg.velocity[i] = 0.1 * 2.0 * M_PI * std::cos(2.0 * M_PI * phase + M_PI);
      }
      else if (joint_names[i] == "R_SHOULDER_Y")
      {
        joint_state_msg.position[i] = 0.1 * std::cos(2.0 * M_PI * phase + M_PI);
        joint_state_msg.velocity[i] = -0.1 * 2.0 * M_PI * std::sin(2.0 * M_PI * phase + M_PI);
      }
      // 左肩关节
      else if (joint_names[i] == "L_SHOULDER_R")
      {
        joint_state_msg.position[i] = 0.1 * std::sin(2.0 * M_PI * phase);
        joint_state_msg.velocity[i] = 0.1 * 2.0 * M_PI * std::cos(2.0 * M_PI * phase);
      }
      else if (joint_names[i] == "L_SHOULDER_Y")
      {
        joint_state_msg.position[i] = 0.1 * std::cos(2.0 * M_PI * phase);
        joint_state_msg.velocity[i] = -0.1 * 2.0 * M_PI * std::sin(2.0 * M_PI * phase);
      }
      // 腰部关节
      else if (joint_names[i] == "WAIST_Y")
      {
        joint_state_msg.position[i] = 0.2 * std::sin(2.0 * M_PI * phase);
        joint_state_msg.velocity[i] = 0.2 * 2.0 * M_PI * std::cos(2.0 * M_PI * phase);
      }
      else if (joint_names[i] == "WAIST_P")
      {
        joint_state_msg.position[i] = 0.1 * std::cos(2.0 * M_PI * phase);
        joint_state_msg.velocity[i] = -0.1 * 2.0 * M_PI * std::sin(2.0 * M_PI * phase);
      }
      else if (joint_names[i] == "WAIST_R")
      {
        joint_state_msg.position[i] = 0.1 * std::sin(2.0 * M_PI * phase + M_PI / 2);
        joint_state_msg.velocity[i] = 0.1 * 2.0 * M_PI * std::cos(2.0 * M_PI * phase + M_PI / 2);
      }
    }

    // 发布消息
    pub->publish(joint_state_msg);

    // 更新时间
    time += dt;

    // 日志输出（调试用，可选）
    RCLCPP_DEBUG(node->get_logger(), "发布行走命令: %s, 位置: %.3f, 速度: %.3f",
                 joint_state_msg.name[10].c_str(),  // leg_r3_joint
                 joint_state_msg.position[10],
                 joint_state_msg.velocity[10]);

    rate.sleep();
    rclcpp::spin_some(node);
  }

  rclcpp::shutdown();
  return 0;
}