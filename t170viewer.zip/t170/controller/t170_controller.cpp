// Copyright 2023 ros2_control Development Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "ros2_control_t170/t170_controller.hpp"

#include <stddef.h>
#include <algorithm>
#include <memory>
#include <string>
#include <vector>
#include <iostream>
#include "rclcpp/qos.hpp"
#include "rclcpp/time.hpp"
#include "rclcpp_lifecycle/node_interfaces/lifecycle_node_interface.hpp"
#include "rclcpp_lifecycle/state.hpp"

using config_type = controller_interface::interface_configuration_type;

namespace ros2_control_t170
{
RobotController::RobotController() : controller_interface::ControllerInterface() {}

controller_interface::CallbackReturn RobotController::on_init()
{
  try
  {
    joint_names_ = auto_declare<std::vector<std::string>>("joints", joint_names_);
    command_interface_types_ = auto_declare<std::vector<std::string>>("command_interfaces", command_interface_types_);
    state_interface_types_ = auto_declare<std::vector<std::string>>("state_interfaces", state_interface_types_);

    // 初始化关节索引映射
    for (size_t i = 0; i < joint_names_.size(); ++i)
    {
      joint_index_map_[joint_names_[i]] = i;
    }
  }
  catch (const std::exception & e)
  {
    RCLCPP_ERROR(get_node()->get_logger(), "初始化失败: %s", e.what());
    return controller_interface::CallbackReturn::ERROR;
  }

  return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::InterfaceConfiguration RobotController::command_interface_configuration() const
{
  controller_interface::InterfaceConfiguration conf = {config_type::INDIVIDUAL, {}};
  conf.names.reserve(joint_names_.size() * command_interface_types_.size());
  for (const auto & joint_name : joint_names_)
  {
    for (const auto & interface_type : command_interface_types_)
    {
      conf.names.push_back(joint_name + "/" + interface_type);
    }
  }
  return conf;
}

controller_interface::InterfaceConfiguration RobotController::state_interface_configuration() const
{
  controller_interface::InterfaceConfiguration conf = {config_type::INDIVIDUAL, {}};
  conf.names.reserve(joint_names_.size() * state_interface_types_.size());
  for (const auto & joint_name : joint_names_)
  {
    for (const auto & interface_type : state_interface_types_)
    {
      conf.names.push_back(joint_name + "/" + interface_type);
    }
  }
  return conf;
}

controller_interface::CallbackReturn RobotController::on_configure(const rclcpp_lifecycle::State &)
{
  auto callback = [this](const sensor_msgs::msg::JointState::SharedPtr msg) -> void
  {
    joint_command_buffer_.writeFromNonRT(msg);
  };

  joint_command_subscriber_ = get_node()->create_subscription<sensor_msgs::msg::JointState>(
    "/joint_commands", rclcpp::SystemDefaultsQoS(), callback);

  RCLCPP_INFO(get_node()->get_logger(), "控制器配置完成，订阅 /joint_commands");
  return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn RobotController::on_activate(const rclcpp_lifecycle::State &)
{
  // 清空接口向量以防重启
  joint_position_command_interface_.clear();
  joint_velocity_command_interface_.clear();
  joint_position_state_interface_.clear();
  joint_velocity_state_interface_.clear();

  // 分配命令接口
  for (auto & interface : command_interfaces_)
  {
    if (interface.get_interface_name().find("position") != std::string::npos)
    {
      joint_position_command_interface_.push_back(std::ref(interface));
    }
    else if (interface.get_interface_name().find("velocity") != std::string::npos)
    {
      joint_velocity_command_interface_.push_back(std::ref(interface));
    }
  }

  // 分配状态接口
  for (auto & interface : state_interfaces_)
  {
    if (interface.get_interface_name().find("position") != std::string::npos)
    {
      joint_position_state_interface_.push_back(std::ref(interface));
    }
    else if (interface.get_interface_name().find("velocity") != std::string::npos)
    {
      joint_velocity_state_interface_.push_back(std::ref(interface));
    }
  }

  // 检查接口是否正确分配
  if (joint_position_command_interface_.size() != joint_names_.size() &&
      joint_velocity_command_interface_.size() != joint_names_.size())
  {
    RCLCPP_ERROR(get_node()->get_logger(), "命令接口数量与关节数量不匹配");
    return controller_interface::CallbackReturn::ERROR;
  }

  RCLCPP_INFO(get_node()->get_logger(), "控制器激活完成");
  return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::return_type RobotController::update(
  const rclcpp::Time & /*time*/, const rclcpp::Duration & /*period*/)
{
  auto latest_command = joint_command_buffer_.readFromRT();
  if (latest_command && *latest_command)
  {
    const auto & msg = **latest_command;
    std::vector<double> positions(joint_names_.size(), 0.0);
    std::vector<double> velocities(joint_names_.size(), 0.0);

    // 映射接收到的位置和速度到控制器关节顺序
    for (size_t i = 0; i < msg.name.size(); ++i)
    {
      auto it = joint_index_map_.find(msg.name[i]);
      if (it != joint_index_map_.end())
      {
        size_t idx = it->second;
        if (i < msg.position.size())
        {
          positions[idx] = msg.position[i];
        }
        if (i < msg.velocity.size())
        {
          velocities[idx] = msg.velocity[i];
        }
      }
    }

    // 设置位置命令
    for (size_t i = 0; i < joint_position_command_interface_.size(); ++i)
    {
      joint_position_command_interface_[i].get().set_value(positions[i]);
    }

    // 设置速度命令
    for (size_t i = 0; i < joint_velocity_command_interface_.size(); ++i)
    {
      joint_velocity_command_interface_[i].get().set_value(velocities[i]);
    }
  }
  else
  {
    // 未收到命令时，设置安全默认值
    for (auto & vel_cmd : joint_velocity_command_interface_)
    {
      vel_cmd.get().set_value(0.0);  // 速度归零
    }
    for (size_t i = 0; i < joint_position_command_interface_.size(); ++i)
    {
      double current_pos = joint_position_state_interface_[i].get().get_value();
      joint_position_command_interface_[i].get().set_value(current_pos);  // 保持当前位置
    }
  }

  return controller_interface::return_type::OK;
}

controller_interface::CallbackReturn RobotController::on_deactivate(const rclcpp_lifecycle::State &)
{
  release_interfaces();
  RCLCPP_INFO(get_node()->get_logger(), "控制器已停用");
  return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn RobotController::on_cleanup(const rclcpp_lifecycle::State &)
{
  return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn RobotController::on_error(const rclcpp_lifecycle::State &)
{
  return controller_interface::CallbackReturn::ERROR;
}

controller_interface::CallbackReturn RobotController::on_shutdown(const rclcpp_lifecycle::State &)
{
  return controller_interface::CallbackReturn::SUCCESS;
}

}  // namespace ros2_control_t170

#include <pluginlib/class_list_macros.hpp>

PLUGINLIB_EXPORT_CLASS(
  ros2_control_t170::RobotController, controller_interface::ControllerInterface)