#include "ros2_control_t170/t170_hardware.hpp"
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>

namespace ros2_control_t170
{
// Helper function to trim whitespace from strings
static inline void trim(std::string & s)
{
  s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](unsigned char ch) {
    return !std::isspace(ch);
  }));
  s.erase(std::find_if(s.rbegin(), s.rend(), [](unsigned char ch) {
    return !std::isspace(ch);
  }).base(), s.end());
}

CallbackReturn RobotSystem::on_init(const hardware_interface::HardwareInfo & info)
{
  if (hardware_interface::SystemInterface::on_init(info) != CallbackReturn::SUCCESS)
  {
    return CallbackReturn::ERROR;
  }

  // Clear and populate joint names, trimming whitespace
  joint_names_.clear();
  for (const auto & joint : info_.joints)
  {
    std::string joint_name = joint.name;
    trim(joint_name);
    joint_names_.push_back(joint_name);
  }

  // Resize state and command vectors based on joint count
  size_t num_joints = joint_names_.size();
  joint_position_.resize(num_joints, 0.0);
  joint_velocities_.resize(num_joints, 0.0);
  joint_position_command_.resize(num_joints, 0.0);
  joint_velocities_command_.resize(num_joints, 0.0);

  // Verify joint count (should be 23)
  if (num_joints != 23)
  {
    RCLCPP_ERROR(rclcpp::get_logger("RobotSystem"), "Expected 23 joints, but found %zu", num_joints);
    return CallbackReturn::ERROR;
  }

  RCLCPP_INFO(rclcpp::get_logger("RobotSystem"), "Hardware initialized with %zu joints", num_joints);
  return CallbackReturn::SUCCESS;
}

std::vector<hardware_interface::StateInterface> RobotSystem::export_state_interfaces()
{
  std::vector<hardware_interface::StateInterface> state_interfaces;
  for (size_t i = 0; i < joint_names_.size(); ++i)
  {
    state_interfaces.emplace_back(joint_names_[i], "position", &joint_position_[i]);
    state_interfaces.emplace_back(joint_names_[i], "velocity", &joint_velocities_[i]);
  }
  return state_interfaces;
}

std::vector<hardware_interface::CommandInterface> RobotSystem::export_command_interfaces()
{
  std::vector<hardware_interface::CommandInterface> command_interfaces;
  for (size_t i = 0; i < joint_names_.size(); ++i)
  {
    command_interfaces.emplace_back(joint_names_[i], "position", &joint_position_command_[i]);
    command_interfaces.emplace_back(joint_names_[i], "velocity", &joint_velocities_command_[i]);
  }
  return command_interfaces;
}

return_type RobotSystem::read(const rclcpp::Time & /*time*/, const rclcpp::Duration & period)
{
  // Simulate hardware read: update state based on commands
  for (size_t i = 0; i < joint_names_.size(); ++i)
  {
    joint_position_[i] = joint_position_command_[i];
    joint_velocities_[i] = joint_velocities_command_[i];
    joint_position_[i] += joint_velocities_command_[i] * period.seconds();
  }
  return return_type::OK;
}

return_type RobotSystem::write(const rclcpp::Time & /*time*/, const rclcpp::Duration & /*period*/)
{
  // TODO: Implement actual hardware write if needed
  return return_type::OK;
}

}  // namespace ros2_control_t170

#include "pluginlib/class_list_macros.hpp"
PLUGINLIB_EXPORT_CLASS(
  ros2_control_t170::RobotSystem, hardware_interface::SystemInterface)