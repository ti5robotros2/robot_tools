# ti5robot_ros2


ros2 launch  ros2_control_t170 t170_controller.launch.py

ros2 launch ros2_control_t170 walk.launch.py

ros2 launch ros2_control_t170 view_t170.launch.py 
